"""
=========================
Video playing made simple
=========================

This shows how to play a video file in expyfun. It requires that FFmpeg
(for Pyglet >= 1.4) or AVBin (otherwise) has already been installed.

@author: drmccloy
"""

from expyfun import ExperimentController, building_doc, fetch_data_file
from expyfun import analyze as ea

print(__doc__)

movie_path = fetch_data_file("video/example-video.mp4")

ec_args = dict(
    exp_name="simple video example",
    window_size=(720, 480),
    full_screen=False,
    participant="foo",
    session="foo",
    version="dev",
    output_dir=None,
)
screenshot = None

with ExperimentController(**ec_args) as ec:
    ec.load_video(movie_path)
    ec.video.set_scale("fit")
    t_zero = ec.video.play()
    while not ec.video.finished:
        if ec.video.playing:
            fliptime = ec.flip()
        if screenshot is None:
            screenshot = ec.screenshot()
        if building_doc:
            break
        ec.check_force_quit()
    ec.delete_video()
    ec.flip()
    ec.screen_prompt("video over", max_wait=1.0)

ea.plot_screen(screenshot)
